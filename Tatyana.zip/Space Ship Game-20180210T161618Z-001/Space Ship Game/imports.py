import pygame
import sys
import math
import random
import os
from pygame.locals import*
pygame.init()
